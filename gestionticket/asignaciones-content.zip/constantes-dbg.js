/* global moment:true */
sap.ui.define([], function () {
  "use strict";
  return {
    ambiente: "qas",
    isLocal: false,
    idProyecto: "app.asignaciones",
    urlApiGatewayLocal: "https://portalseidor-ms-asignaciones-base-dev.cfapps.us10-001.hana.ondemand.com/",
    destApiGateway:
      jQuery.sap.getModulePath("app.asignaciones") +
      "/" +
      "dest-asigwebapi",
    services: {
      //Rol
      obtenerRoles: "/rest/rol/obtenerRoles()",
      //Peps
      obtenerPeps: "/rest/pep/obtenerPeps()",
      //Consultores
      obtenerConsultores: "/rest/consultor/obtenerConsultores()",
      //Asignaciones
      obtenerAsignacionesXFiltro: "/rest/asignacion/obtenerAsignacionesXFiltro",
      registrarAsignacion: "/rest/asignacion/registrarAsignacion",
      eliminarAsignacion: "/rest/asignacion/eliminarAsignacion",
    },
  };
});
