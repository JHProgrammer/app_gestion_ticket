sap.ui.define([], function () {
  "use strict";
  return {
    registrarAsignaciones: function (oParam) {
      let asignaciones = {};
      let roles = [];
      asignaciones.ID_ESTADO = 1;
      asignaciones.CORREO = oParam.correo;
      asignaciones.NOMBRE = oParam.nombres;
      asignaciones.APELLIDO = oParam.apellidos;
      asignaciones.RUC = oParam.ruc;
      asignaciones.USUARIO = oParam.asignaciones;
      asignaciones.RAZON_SOCIAL = oParam.razonSocial;
      asignaciones.TIPO_EMISOR = oParam.tipoDeEmisor;
      asignaciones.CODIGO_TIPO_EMISOR = oParam.selectTipoEmisor;

      asignaciones.TELEFONO = "";

      for (let i = 0; i < oParam.roles.length; i++) {
        let rolAsignaciones = {};
        rolAsignaciones.ID_ROL = oParam.roles[i];
        rolAsignaciones.ID_ESTADO = 1;
        roles.push(rolAsignaciones);
      }
      let modData = {
        asignacionesCab: asignaciones,

        registrarRoles: roles,
      };

      return modData;
    },
    actualizarAsignaciones: function (oParam) {
      let asignaciones = {};
      let roles = [];

      asignaciones.ID = oParam.idAsignaciones;
      asignaciones.ID_ESTADO = 1;
      asignaciones.CORREO = oParam.correo;
      asignaciones.NOMBRE = oParam.nombres;
      asignaciones.APELLIDO = oParam.apellidos;
      asignaciones.RUC = oParam.ruc;
      asignaciones.USUARIO = oParam.asignaciones;
      asignaciones.RAZON_SOCIAL = oParam.razonSocial;
      asignaciones.TIPO_EMISOR = oParam.tipoDeEmisor;
      asignaciones.CODIGO_TIPO_EMISOR = oParam.tipoDeEmisor;
      for (let i = 0; i < oParam.roles.length; i++) {
        let rolAsignaciones = {};
        rolAsignaciones.ID_ROL = oParam.roles[i];
        rolAsignaciones.ID_ESTADO = 1;
        roles.push(rolAsignaciones);
      }
      let modData = {
        asignacionesCab: asignaciones,
        registrarRoles: roles,
      };

      return modData;
    },
    eliminarAsignaciones: function (oParam) {
      let deleteAsignaciones = [];

      for (let i = 0; i < oParam.length; i++) {
        let asignaciones = {};

        asignaciones.ID = oParam[i].idAsignaciones;
        asignaciones.CORREO = oParam[i].correo;
        asignaciones.USUARIO = oParam[i].asignaciones;

        deleteAsignaciones.push(asignaciones);
      }

      let modData = {
        eliminarAsignaciones: deleteAsignaciones,
      };

      return modData;
    },
    obtenerRolesXAsignaciones: function (idAsignaciones) {
      let modData = [];
      let keyValue = "USUARIO_ID=" + idAsignaciones;
      modData.push(keyValue);
      return modData;
    },
    procesoObtenerRazonSocialXRuc: function (oParam) {
      let obtenerRazonSocial = [];
      let object = {};
      let object2 = {};

      object.STCD1 = oParam;

      obtenerRazonSocial.push(object);

      object2.LT_STCD1 = obtenerRazonSocial;

      return object2;
    },
    onFiltrarTabla: function (buscar, roles) {
      return {
        listaCodigosRoles: roles,
        buscar: buscar,
      };
    },
  };
});
